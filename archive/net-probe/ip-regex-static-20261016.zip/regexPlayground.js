import { testRegex } from './regexTester.js';

const $ = (id) => document.getElementById(id);
const pattern = $('playground-pattern');
const sample = $('playground-text');
const highlight = $('playground-highlight');
const status = $('playground-status');
const list = $('playground-matches');
const count = $('playground-count');
const matchesWrap = $('playground-matches-wrap');

function renderHighlight(text, matches) {
  highlight.replaceChildren();
  if (!text) { highlight.textContent = '匹配的文本将在这里高亮显示'; return; }
  let cursor = 0;
  for (const match of matches) {
    if (match.start < cursor) continue;
    highlight.append(document.createTextNode(text.slice(cursor, match.start)));
    if (match.end > match.start) {
      const mark = document.createElement('mark');
      mark.textContent = text.slice(match.start, match.end);
      highlight.append(mark);
    }
    cursor = match.end;
  }
  highlight.append(document.createTextNode(text.slice(cursor)));
}

function renderMatches(matches) {
  list.replaceChildren();
  if (!matches.length) {
    const empty = document.createElement('li');
    empty.className = 'empty-match';
    empty.textContent = '没有匹配结果';
    list.append(empty);
    return;
  }
  matches.forEach((match, index) => {
    const item = document.createElement('li');
    const position = document.createElement('span');
    position.textContent = `#${index + 1} · 位置 ${match.start}`;
    const value = document.createElement('code');
    value.textContent = match.value || '∅ 空匹配';
    item.append(position, value);
    if (match.groups.length) {
      const groups = document.createElement('small');
      groups.textContent = `捕获组：${match.groups.map((group, i) => `${i + 1}: ${group ?? '未匹配'}`).join(' · ')}`;
      item.append(groups);
    }
    list.append(item);
  });
}

function update() {
  const text = sample.value;
  const result = testRegex(pattern.value, text, {
    global: $('flag-global').checked,
    ignoreCase: $('flag-ignore-case').checked,
    multiline: $('flag-multiline').checked,
  });
  const ready = Boolean(pattern.value && text);
  status.textContent = result.error || (ready ? `${result.matches.length}${result.truncated ? '+' : ''} 处命中` : '等待输入');
  status.classList.toggle('error', Boolean(result.error));
  status.classList.toggle('miss', Boolean(ready && !result.error && !result.matches.length));
  count.textContent = `${result.matches.length}${result.truncated ? '+' : ''} 项`;
  renderHighlight(text, result.error ? [] : result.matches);
  renderMatches(result.error ? [] : result.matches);
  matchesWrap.hidden = !$('show-matches').checked;
}

export function useGeneratedRegex(regex, ips) {
  pattern.value = regex;
  sample.value = ips.join('\n');
  $('flag-global').checked = true;
  update();
}

export function clearGeneratedRegex(regex, ips) {
  if (pattern.value !== regex || sample.value !== ips.join('\n')) return;
  pattern.value = '';
  sample.value = '';
  update();
}

for (const id of ['playground-pattern', 'playground-text', 'flag-global', 'flag-ignore-case', 'flag-multiline', 'show-matches']) {
  $(id).addEventListener('input', update);
  $(id).addEventListener('change', update);
}

$('playground-example').addEventListener('click', () => {
  pattern.value = '\\b(?:192\\.168\\.1\\.10|10\\.0\\.0\\.5)\\b';
  sample.value = '服务器 A：192.168.1.10\n服务器 B：10.0.0.5\n其他地址：172.16.0.1';
  $('flag-global').checked = true;
  update();
});
$('playground-clear').addEventListener('click', () => { pattern.value = ''; sample.value = ''; update(); pattern.focus(); });
$('use-ip-regex').addEventListener('click', () => {
  const generated = document.getElementById('copy-regex').disabled ? '' : document.getElementById('regex-output').textContent;
  if (!generated) { status.textContent = '请先在上方生成 IP 正则'; status.classList.add('error'); return; }
  useGeneratedRegex(generated, JSON.parse($('use-ip-regex').dataset.ips || '[]'));
  pattern.focus();
});
