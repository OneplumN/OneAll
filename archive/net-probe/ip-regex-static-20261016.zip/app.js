import { compileIpRegexFromText, expandIpRegex, parseIpLines } from './ipRegexTool.js';
import './regexPlayground.js';

const $ = (id) => document.getElementById(id);
let currentRegex = '';
let reverseIps = [];
let lastGeneratedIps = [];

function setSummary(result) {
  const node = $('summary');
  node.replaceChildren();
  for (const [label, value, tone] of [['有效', result.matchedCount, 'valid'], ['重复', result.duplicateCount, 'duplicate'], ['无效', result.invalidIps.length, 'invalid']]) {
    const item = document.createElement('span');
    item.className = `summary-item${value ? ` ${tone}` : ''}`;
    item.textContent = `${label} ${value} 个`;
    node.append(item);
  }
  if (result.invalidIps.length) {
    const detail = document.createElement('span');
    detail.className = 'invalid-detail';
    detail.textContent = `无效 IP：${result.invalidIps.join('、')}`;
    node.append(detail);
  }
}

const tabs = ['tab-ip', 'tab-reverse', 'tab-test'].map($);
function activateTab(tab, focus = false) {
  for (const item of tabs) {
    const active = item === tab;
    item.setAttribute('aria-selected', String(active));
    item.tabIndex = active ? 0 : -1;
    $(item.getAttribute('aria-controls')).hidden = !active;
  }
  if (focus) tab.focus();
}

function runExpand(expectedIps) {
  try {
    const result = expandIpRegex($('reverse-input').value, Number($('limit').value));
    reverseIps = result.ips;
    $('reverse-output').value = reverseIps.join('\n');
    $('copy-ips').disabled = !reverseIps.length;
    const message = $('reverse-message');
    message.className = 'reverse-message';
    if (expectedIps && !result.truncated) {
      const covered = new Set(reverseIps);
      const same = covered.size === expectedIps.length && expectedIps.every((ip) => covered.has(ip));
      message.textContent = same ? `校验通过：覆盖 ${result.count} 个 IP` : `覆盖 ${result.count} 个 IP，与有效输入的 ${expectedIps.length} 个不一致`;
      message.classList.add(same ? 'good' : 'bad');
    } else {
      message.textContent = result.truncated ? `仅展示前 ${result.limit} 个 IP；可提高展示上限继续检查` : `覆盖 ${result.count} 个 IP`;
    }
  } catch (error) {
    reverseIps = []; $('reverse-output').value = ''; $('copy-ips').disabled = true;
    $('reverse-message').className = 'reverse-message bad';
    $('reverse-message').textContent = error instanceof Error ? error.message : '解析失败，请检查正则';
  }
}

function generate() {
  const result = compileIpRegexFromText($('ip-input').value);
  currentRegex = result.regex;
  lastGeneratedIps = result.normalizedIps;
  $('use-ip-regex').dataset.ips = JSON.stringify(lastGeneratedIps);
  $('regex-output').textContent = currentRegex || '请至少输入一个合法 IPv4 地址';
  $('copy-regex').disabled = !currentRegex;
  setSummary(result);
}

for (const [index, tab] of tabs.entries()) {
  tab.addEventListener('click', () => activateTab(tab));
  tab.addEventListener('keydown', (event) => {
    const next = event.key === 'ArrowRight' ? (index + 1) % tabs.length
      : event.key === 'ArrowLeft' ? (index + tabs.length - 1) % tabs.length
      : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : -1;
    if (next < 0) return;
    event.preventDefault();
    activateTab(tabs[next], true);
  });
}

$('ip-input').addEventListener('input', () => { $('input-count').textContent = `输入 ${parseIpLines($('ip-input').value).length} 个`; });
$('generate').addEventListener('click', generate);
$('example').addEventListener('click', () => { $('ip-input').value = '192.168.1.10\n192.168.1.11\n192.168.1.12\n10.0.0.5\n10.0.0.6'; $('input-count').textContent = '输入 5 个'; generate(); });
$('clear').addEventListener('click', () => {
  $('ip-input').value = ''; $('input-count').textContent = '输入 0 个'; currentRegex = ''; lastGeneratedIps = [];
  delete $('use-ip-regex').dataset.ips;
  $('regex-output').textContent = '等待生成...'; $('copy-regex').disabled = true;
  $('summary').textContent = '等待输入';
});
$('copy-regex').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(currentRegex); $('copy-regex').textContent = '已复制 ✓'; setTimeout(() => $('copy-regex').textContent = '复制', 1500); }
  catch { $('copy-regex').textContent = '复制失败'; }
});
$('use-generated').addEventListener('click', () => {
  $('reverse-input').value = currentRegex;
  $('reverse-output').value = '';
  reverseIps = [];
  $('copy-ips').disabled = true;
  $('reverse-message').className = currentRegex ? 'reverse-message' : 'reverse-message bad';
  $('reverse-message').textContent = currentRegex ? '' : '请先生成正则表达式';
});
$('expand').addEventListener('click', () => runExpand(
  currentRegex && $('reverse-input').value.trim() === currentRegex.trim() ? lastGeneratedIps : undefined,
));
$('copy-ips').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(reverseIps.join('\n')); $('copy-ips').textContent = '已复制 ✓'; setTimeout(() => $('copy-ips').textContent = '复制列表', 1500); }
  catch { $('copy-ips').textContent = '复制失败'; }
});
