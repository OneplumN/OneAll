const MAX_TEXT_LENGTH = 20_000;
const MAX_PATTERN_LENGTH = 20_000;
const MAX_MATCHES = 300;

export function testRegex(pattern, text, options = {}) {
  if (!pattern) return { matches: [], truncated: false, error: '' };
  if (pattern.length > MAX_PATTERN_LENGTH) return { matches: [], truncated: false, error: '表达式超过 20,000 字符上限' };
  if (text.length > MAX_TEXT_LENGTH) return { matches: [], truncated: false, error: '测试文本超过 20,000 字符上限' };

  const flags = `${options.ignoreCase ? 'i' : ''}${options.multiline ? 'm' : ''}g`;
  let expression;
  try {
    expression = new RegExp(pattern, flags);
  } catch (error) {
    return { matches: [], truncated: false, error: `正则语法错误：${error.message}` };
  }

  const matches = [];
  let truncated = false;
  for (const match of text.matchAll(expression)) {
    if (matches.length === MAX_MATCHES) { truncated = true; break; }
    matches.push({
      start: match.index,
      end: match.index + match[0].length,
      value: match[0],
      groups: match.slice(1),
    });
    if (!options.global) break;
  }
  return { matches, truncated, error: '' };
}
